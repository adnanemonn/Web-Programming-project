@extends('admin.master')

@section('title')
	Category Entry
@endsection

@section('content-heading')
	Category
@endsection

@section('mainContent')
	<div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped">
                        
                        <tr>
                            <th>Order No:</th>
                            <th>Name</th>
                            <th>addres:</th>
                            <th>phone:</th>
                            <th>product name:</th>
                            <th>Quantity:</th>
                            <th>Price:</th>
                        </tr>
                        @foreach($all_orders as $order)
                            <tr>
                                <td>{{$order->id}}</td>
                                <td>{{$order->firstname}} {{$order->lastname}}</td>
                                <td>{{$order->address}}</td>
                                <td>{{$order->phone}}</td>
                                <td>{{$order->product_name}}</td>
                                <td>{{$order->quantity}}</td>
                                <td>Tk: {{$order->price}}</td>
                            </tr>
                        @endforeach
                    </table>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
@endsection

@push('scripts')
    <script type="text/javascript">
    	$( document ).ready(function($) {


		  $( "#teatype_submit" ).click(function(e) {
		  		e.preventDefault();
			  	console.log("loll");

			  	$('#teatype_form').submit();
			});

	});

    </script>
@endpush

