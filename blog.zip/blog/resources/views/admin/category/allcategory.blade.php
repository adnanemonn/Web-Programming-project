@extends('admin.master')

@section('title')
	Category Entry
@endsection

@section('content-heading')
	Category
@endsection

@section('mainContent')
	<div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped">
                        
                        <tr>
                            <th>product No:</th>
                            <th>Name</th>
                            <th>price:</th>
                            <th>Edit:</th>
                            <th>Delete:</th>
                        </tr>
                        @foreach($category as $single_category)
                            <tr>
                                <td>{{$single_category->id}}</td>
                                <td>{{$single_category->name}}</td>
                                <td>Tk: {{$single_category->price}}</td>
                                <td><a style="color: black;" href="{{url('')}}/edit_product/{{$single_category->id}}">Edit</a></td>
                                <td><a style="color: black;" href="{{url('')}}/delete_product/{{$single_category->id}}">Delete</a></td>
                            </tr>
                        @endforeach
                    </table>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
@endsection

@push('scripts')
    <script type="text/javascript">
    	$( document ).ready(function($) {


		  $( "#teatype_submit" ).click(function(e) {
		  		e.preventDefault();
			  	console.log("loll");

			  	$('#teatype_form').submit();
			});

	});

    </script>
@endpush

