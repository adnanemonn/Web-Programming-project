@extends('admin.master')

@section('title')
	Category Entry
@endsection

@section('content-heading')
	Category
@endsection

@section('mainContent')
	<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Basic Form Elements
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form enctype="multipart/form-data" role="form" action="{{url('')}}/addtea_type" method="post" id="teatype_form">
                                    	@csrf
                                        <div class="form-group">
                                            <label>Name: </label>
                                            <input name="name" type="text" class="form-control">
                                            <!-- <p class="help-block">Example block-level help text here.</p> -->
                                        </div>

                                        <div class="form-group">
                                            <label>price: </label>
                                            <input name="price" type="number" class="form-control">
                                            <!-- <p class="help-block">Example block-level help text here.</p> -->
                                        </div>

                                        <div class="form-group">
                                            <label>Demo Image: </label>
                                            <input type="file" name="image" class="form-control">
                                            <!-- <p class="help-block">Example block-level help text here.</p> -->
                                        </div>

                                       <!--  <div class="form-group">
                                            <label>Description</label>
                                            <input class="form-control">
                                            <p class="help-block">Example block-level help text here.</p> 
                                        </div> -->
                                        
                                        <div class="form-group">
                                            <label>Description: </label>
                                            <textarea name="description" class="form-control" rows="3"></textarea>
                                        </div>
                                        <!-- <a class="btn btn-default" id="teatype_submit" >Click me</a>
                                        <a type="submit" value="submit" name="submit" > -->
                                        <button type="submit" class="btn btn-default">Submit</button>
                                        
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
@endsection

@push('scripts')
    <script type="text/javascript">
    	$( document ).ready(function($) {


		  $( "#teatype_submit" ).click(function(e) {
		  		e.preventDefault();
			  	console.log("loll");

			  	$('#teatype_form').submit();
			});

	});

    </script>
@endpush

