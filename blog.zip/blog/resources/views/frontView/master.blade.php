<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	 <!-- Title -->
	<title>chaa.com @yield('title_area')</title>

	<!-- CSS -->
	@yield('css')
</head>	
<body>
	<!-- header_area start -->
	@include('frontView.inc.header')
	<!-- header_area end -->

	

	<!-- favourite_tea start-->
	@yield('favourite')
	<!-- favourite_tea end-->

	<!-- design_area start-->
	@include('frontView.inc.design')
	<!-- design_area end-->

	<!-- gallery_area start-->
	@yield('gallery_area')
	<!-- gallery_area end-->

	<!--counter Up start here -->
	@yield('counter')

<!-- footer_area start -->
	@include('frontView.inc.footer')
<!-- footer_area end -->

	<!-- js  code -->
	@yield('js')
</body>
</html>