<!-- service_area start-->
	<section class="service_area" id="service">
		<div class="container">
			<div class="row">
			    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="box_part text-center">   
                        <i class="fas fa-info" aria-hidden="true"></i>
						<div class="title">
							<h4>Information of tea</h4>
						</div>  
						<div class="text">
							<span>Lorem ipsum dolor sit amet, id quo eruditi eloquentiam. Assum decore te sed. Elitr scripta ocurreret qui ad.</span>
						</div> 
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="box_part text-center">   
                        <i class="fas fa-dolly" aria-hidden="true"></i>
						<div class="title">
							<h4>Easily delivery</h4>
						</div>  
						<div class="text">
							<span>Lorem ipsum dolor sit amet, id quo eruditi eloquentiam. Assum decore te sed. Elitr scripta ocurreret qui ad.</span>
						</div>  
					</div>
				</div> 
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="box_part text-center">   
                        <i class="fas fa-seedling" aria-hidden="true"></i>
						<div class="title">
							<h4>offer Best brand</h4>
						</div>  
						<div class="text">
							<span>Lorem ipsum dolor sit amet, id quo eruditi eloquentiam. Assum decore te sed. Elitr scripta ocurreret qui ad.</span>
						</div>
					</div>
				</div>	 
			</div>		
		</div>
	</section>
<!-- service_area end-->	