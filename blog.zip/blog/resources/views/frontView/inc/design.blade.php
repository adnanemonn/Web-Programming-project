	<!-- design_area start-->
	<section class="design_area pt-100 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-xl-6">
					<div class="design_content">
						<h3>Over 45 million cups.<br>To 117 countries.</h3>
						<p>We are a culture that’s changing the way tea is perceived and consumed,<br> one cup at a time.</p>
						<a class="box_link" href="">learn more<i class="fas fa-angle-right"></i></a>
					</div>
				</div>	
			</div>			
		</div>
	</section>
	<!-- design_area end-->