<!-- footer_area start -->
	<section class="footer_area pt-50 pb-50" id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xl-3">
					<div class="single_footer">
						<h2>chaa<span class="logo_color">.com</span></h2>
						<h5>tea company</h5>
						<div class="customer_help">
							<h3>Customer Help</h3>
							<p>(800) 800-8327</p>
						</div>
						<div class="social_heading">
							<h3>Follow Us</h3>
						</div>
						<div class="social_icon">
							<a href=""><i class="fab fa-facebook-f"></i></a>
							<a href=""><i class="fab fa-twitter"></i></a>
							<a href=""><i class="fab fa-dribbble"></i></a>
							<a href=""><i class="fab fa-google"></i></a>
							<a href=""><i class="fab fa-instagram"></i></a>
						</div>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_footer">
						<h4>information link</h4>
						<ul>
							<li><a href=""><i class="fas fa-angle-right"></i>contact us</a></li>
							<li><a href=""><i class="fas fa-angle-right"></i>blog</a></li>
							<li><a href=""><i class="fas fa-angle-right"></i>shopping bag</a></li>
							<li><a href=""><i class="fas fa-angle-right"></i>how you shopping our site</a></li>
							<li><a href=""><i class="fas fa-angle-right"></i>question</a></li>
							<li><a href=""><i class="fas fa-angle-right"></i>our conditions</a></li>
						</ul>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_footer">
						<h4>Contact</h4>
						<ul>
							<li><i class="far fa-envelope"></i>Email: chaa4@gmail.com </li>
							<li><i class="fas fa-mobile-alt"></i>mobile:+017 101 0000 000</li>
							<li><i class="fas fa-mobile-alt"></i>Phone: +88 (0) 101 0000</li>
							<li><i class="fas fa-fax"></i>Fax: +88 (0) 202 0000</li>
						</ul>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_footer">
						<h4>Newsletter</h4>
						<p class="title_underline">Sign up to our newsletter and save 15% on your first order!</p>
						<form action="#">
							<div class="form_field">
								<input type="text" placeholder="enter email"/>
								<a class="box_btn" href="">Sign up</a>
							</div>
						</form>
					</div>
				</div>	
			</div>	
		</div>
	</section>

	<!-- copyright area start-->
	<section class="copyright_area pt-10 pb-10">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<p  style="text-align: center;">All Right Resceved &copy; 2019 | Developed by Kazi Emran & Mahfuzur Rahman</p>
				</div>
			</div>
		</div>
	</section>
	<!-- copyright area end-->
<!-- footer_area end -->
	