<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
}); */

Route::get('/','FrontController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/catagory/save','CatagoryController@index');

Route::post('/addtea_type','TeaTypeController@create');
Route::get('/tea_details/{id}','TeaTypeController@details');
Route::get('/order_item','OrdersController@index');

Route::post('/placeorder','OrdersController@create');
Route::get('/allorders','OrdersController@all_orders');
Route::get('/allproducts','CatagoryController@allproducts');

Route::get('/edit_product/{id}','CatagoryController@editproducts');
Route::get('/delete_products/{id}','CatagoryController@deleteproducts');
Route::get('/searchProduct','FrontController@search')->name('searchProduct');

