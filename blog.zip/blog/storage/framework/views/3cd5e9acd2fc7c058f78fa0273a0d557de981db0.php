<?php $__env->startSection('title_area'); ?>
	| online delivery website
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<!-- CSS -->


	<!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,600,700,700i" rel="stylesheet"/> 
	<!-- Font Awesome Css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/all.min.css" media="all"/>
	<!-- favicon Css -->
	<link rel="shortcut icon" href="<?php echo e(asset('frontEnd')); ?>/assets/img/favicon.png"/>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/assets/css/bootstrap.min.css"/>
	<!-- owl carousel css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/owl.carousel.css" media="all" />
	<!--magnific-popup-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/magnific-popup.css" media="all" />
	<!-- Main css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/style.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('favourite'); ?>

	<!-- welcome_area start-->
	<?php echo $__env->make('frontView.inc.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- welcome_area end-->

	<!-- service_area start-->
	<?php echo $__env->make('frontView.inc.service', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- service_area end-->

	
	<!-- favourite_tea start-->
	<section class="favourite_tea pt-100 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<!-- section_content -->
					<div class="section_content">
						<h2><i class="fas fa-coffee"></i><i class="fas fa-mug-hot"></i>Latest Tea</h2>
					</div>
				</div>	
			</div>
			<div class="row">
				<!-- favourite_box -->
				<!-- <div class="favourite_box carousel">		 -->

			<?php $__currentLoopData = $tea_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-xl-4">
					<div class="single_favourite">
						<div class="favourite_img">
							<img src="<?php echo e(asset('images')); ?>/<?php echo e($tea->image); ?>" alt="<?php echo e($tea->images); ?>" />
						</div>	
						<div class="favourite_content">
							<h4><?php echo e($tea->name); ?></h4>
						    <p class="text_center"><?php echo e($tea->description); ?></p>
							<p class="tea_price">TK. <?php echo e($tea->price); ?>

							<!-- <span class="price-off">(30% Off)</span></p> -->
						</div>
						<div class="hover_link">
							<a class="box_add" href="<?php echo e(url('')); ?>/tea_details/<?php echo e($tea->id); ?>"><i class="fas fa-cart-plus" aria-hidden="true"></i>BUY NOW!!</a>
							<a class="box_view" href="<?php echo e(url('')); ?>/tea_details/<?php echo e($tea->id); ?>">view details</a>
						</div> 
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- <div class="col-xl-4">
					<div class="single_favourite">
						<div class="favourite_img">
							<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/favourite/2.jpg" alt="" />
						</div>	
						<div class="favourite_content">
							<h4>Namsang Classic Tea</h4>
						    <p>Our Rooibos derives from the finest organic leaves of the Rooibos or Red Bush plant in the Cederberg mountains of South Africa.</p>
							<p class="tea_price">TK. 980
							<span class="price-off">(30% Off)</span></p>
						</div>
						<div class="hover_link">
							<a class="box_add" href=""><i class="fas fa-cart-plus" aria-hidden="true"></i>add to cart</a>
							<a class="box_view" href="detailes2.html">view details</a>
						</div> 
					</div>
				</div>
				<div class="col-xl-4">
					<div class="single_favourite">
						<div class="favourite_img">
							<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/favourite/3.jpg" alt="" />
						</div>	
						<div class="favourite_content">
							<h4>Margaret's Spring tea</h4>
						    <p>Our Rooibos derives from the finest organic leaves of the Rooibos or Red Bush plant in the Cederberg mountains of South Africa.</p>
							<p class="tea_price">TK. 980
							<span class="price-off">(30% Off)</span></p>
						</div>
						<div class="hover_link">
							<a class="box_add" href=""><i class="fas fa-cart-plus" aria-hidden="true"></i>add to cart</a>
							<a class="box_view" href="detailes3.html">view details</a>
						</div> 
					</div>
				</div> -->
			</div>			
		</div>
	</section>
	<!-- favourite_tea end-->	
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('gallery_area'); ?>
	<!-- gallery_area start-->

	<section class="gallery_area pt-100 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<!-- section_content -->
					<div class="section_content">
						<h2><i class="fas fa-coffee"></i>In The Spotlight</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-12">
					<div class="gallery_list">
						<ul>
							<li data-filter="*">all</li>
							<!-- <li data-filter=".Sellers">Best Sellers</li>
							<li data-filter=".Arrivals"> New Arrivals  </li>
							<li data-filter=".Teas_Week">Teas of the Week</li> -->
						</ul>	
					</div>
				</div>
			</div>
				<div class="row grid">
				<?php $__currentLoopData = $tea_type_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="col-xl-4 grid-item">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('images')); ?>/<?php echo e($tea->image); ?>" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery1.html" class="title"><?php echo e($item->name); ?></a>
								<p>$<?php echo e($item->price); ?></p>
								<a href="<?php echo e(url('')); ?>/tea_details/<?php echo e($tea->id); ?>" class="box_btn">Buy Now!!</a>
							</div>
						</div>
					</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


					<!-- <div class="col-xl-4 grid-item Arrivals Sellers">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/2.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery2.html" class="title">Green teas</a>
								<p><del>$145.00</del> $135.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Arrivals Sellers">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/3.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery3.html" class="title">white teas</a>
								<p><del>$145.00</del> $125.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Sellers Arrivals">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/4.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery4.html" class="title">Blended teas</a>
								<p>$ 14.99</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Arrivals">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/5.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery5.html" class="title">Bombay Cutting Chai</a>
								<p><del>$145.00</del> $135.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Sellers  Teas of the Week">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/6.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery6.html" class="title">Castleton Exotic Tea</a>
								<p><del>$145.00</del> $135.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Teas_Week">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/7.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery7.html" class="title">kashmiri kahwa</a>
								<p><del>$145.00</del> $135.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div>
					<div class="col-xl-4 grid-item Teas_Week">
						<div class="single_gallery">
							<div class="single_gallery_img">
								<img src="<?php echo e(asset('frontEnd')); ?>/assets/img/gallery/8.jpg" alt="image" />
							</div>
							<div class="gallery_content">
								<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></br>
								<a href="gallery8.html" class="title">Calming Green Tea</a>
								<p>$165.00</p>
								<a href="" class="box_btn">add to cart</a>
							</div>
						</div>
					</div> -->
				</div>	
				<div class="row">
					<div class="col-xl-12">
						<div class="total_tea text_center">
							<a href="" class="box_btn">view more</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- gallery_area end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('counter'); ?>
	<!--counter Up start here -->
	<section class="counter_area pt-100 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-xl-3">
					<div class="single_counter">
						<i class="fas fa-users"></i>
						<p><span class="counter">234</span></p>
						<h4>Happy Clients</h4>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_counter">
						<i class="fas fa-briefcase"></i>
						<p><span class="counter">21</span></p>
						<h4>Projects Compleated</h4>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_counter">
						<i class="fas fa-business-time"></i>
						<p><span class="counter">13</span></p>
						<h4>Business Partners</h4>
					</div>
				</div>
				<div class="col-xl-3">
					<div class="single_counter">
						<i class="fas fa-layer-group"></i>
						<p><span class="counter">899</span></p>
						<h4>liens Of Code</h4>
					</div>
				</div>	
			</div>
		</div>	
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- js  code -->
	<!-- library function -->
	<script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.js"></script>
	<!-- Popper JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/bootstrap.min.js"></script>
	<!-- owl.carousel.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/owl.carousel.min.js"></script>
	<!-- Manific Popup JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
	<!-- Isotope JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/isotope.min.js"></script>
	<!-- counterup.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.counterup.min.js"></script>
	<!-- Imageload JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/imageloaded.min.js"></script>
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/wow.min.js"></script>
	<!-- Waypoint JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/waypoint.min.js"></script>
	<!-- main js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('frontView.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>