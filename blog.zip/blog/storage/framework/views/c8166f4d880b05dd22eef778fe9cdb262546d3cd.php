<?php $__env->startSection('title'); ?>
	Category Entry
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-heading'); ?>
	Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
	<div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped">
                        
                        <tr>
                            <th>Order No:</th>
                            <th>Name</th>
                            <th>addres:</th>
                            <th>phone:</th>
                            <th>product name:</th>
                            <th>Quantity:</th>
                            <th>Price:</th>
                        </tr>
                        <?php $__currentLoopData = $all_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->firstname); ?> <?php echo e($order->lastname); ?></td>
                                <td><?php echo e($order->address); ?></td>
                                <td><?php echo e($order->phone); ?></td>
                                <td><?php echo e($order->product_name); ?></td>
                                <td><?php echo e($order->quantity); ?></td>
                                <td>Tk: <?php echo e($order->price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
    	$( document ).ready(function($) {


		  $( "#teatype_submit" ).click(function(e) {
		  		e.preventDefault();
			  	console.log("loll");

			  	$('#teatype_form').submit();
			});

	});

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>