<?php $__env->startSection('title_area'); ?>
	| online delivery website
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<!-- CSS -->


	<!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,600,700,700i" rel="stylesheet"/> 
	<!-- Font Awesome Css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/all.min.css" media="all"/>
	<!-- favicon Css -->
	<link rel="shortcut icon" href="<?php echo e(asset('frontEnd')); ?>/assets/img/favicon.png"/>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/assets/css/bootstrap.min.css"/>
	<!-- owl carousel css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/owl.carousel.css" media="all" />
	<!--magnific-popup-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/magnific-popup.css" media="all" />
	<!-- Main css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/style.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('favourite'); ?>
	<section class="slider_area mt-95">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<div class="slider_content">
						<h3>view details</h3>
						<p>home/view details/<?php echo e($single_tea->name); ?></p>
					</div>
				</div>
			</div>		
		</div>
	</section>
	<!-- slider_area end -->
	<!-- details_area start-->
	<section class="details_area pt-100 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<div class="details_content">
						<div class="title">
							<h2><?php echo e($single_tea->name); ?></h2>
						</div>
						<p class="title_content"><?php echo e($single_tea->description); ?></p>
					</div>	
				</div>
			</div>
			<div class="row">
				<div class="col-xl-6">
					<div class="details_img">
						<img src="<?php echo e(asset('images')); ?>/<?php echo e($single_tea->image); ?>" alt="<?php echo e($single_tea->images); ?>" />
						
					</div>
				</div>
				<div class="col-xl-6">
					<div class="product_sel_details">
						<p>Like a medieval gruit; strong yet embracing.</p>
						<i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i>
						<h4>Select a Size</h4>
						<div class="product_box">
							<div class="product_box_a">
								<p><span>3.5oz / 100gm</span></p>
								<p class="no_cups_sm">40 cups</p>
							</div>
							<!-- <div class="product_box_b">
								<p><span>0.4oz / 10gm</span></p>
								<p class="no_cups_sm">4 cups</p>
							</div> -->
						</div>
						<form method="get" action="<?php echo e(url('')); ?>/order_item" id="order_form">
							<div class="product_amount">
								<span class="product_variant_qty_label">qty</span>
								<input value="1" min="1" name="quantity" type="number"/>
								<input value="<?php echo e($single_tea->id); ?>" name="single_tea_id"  type="hidden"/>
								<span>tk <?php echo e($single_tea->price); ?></span>	
							</div>	
							<div class="product_link">
								<a class="box_btn" onclick="event.preventDefault();
                                                     document.getElementById('order_form').submit();"><i class="fas fa-cart-plus" aria-hidden="true"></i>Buy Now</a>
							</div>
							<div class="information">
								<p>delivery in 24 working hours.<br/>delivery to whole Bangladesh by quickly
							</p>
							</div>
						</form>
					</div>	
				</div>
			</div>
		</div>		
	</section>
	<!-- details_area end-->
	<!-- description_area start-->
	<section class="description_area pt-50 pb-50">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<div class="description_part">
						<h3>description</h3>
						<p>This blend is one of the first products aimed at combining the health benefits of green tea with Tulsi (Holy Basil) leaves. A potpourri of flavors, this tea has classic features and goodness of a masala chai. It's wellness in a cup.</p>
						<p class="parag_p">Note: CTC teas are not to be brewed in infuser or pincer.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-12">
					<div class="ingredients_part">
						<h3>ingredients</h3>
						<div class="ingredients_img">
							<img src="<?php echo e(asset('frontEnd/assets')); ?>/img/ingredients/1.jpg" alt="" />
							<h5>Green tea</h5>
						</div>
						<div class="ingredients_img">
							<img src="<?php echo e(asset('frontEnd/assets')); ?>/img/ingredients/2.jpg" alt="" />
							<h5>Holy basil<br/>(Tulsi)</h5>
						</div>	
					</div>
				</div>
			</div>
		</div>		
	</section>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- js  code -->
	<!-- library function -->
	<script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.js"></script>
	<!-- Popper JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/bootstrap.min.js"></script>
	<!-- owl.carousel.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/owl.carousel.min.js"></script>
	<!-- Manific Popup JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
	<!-- Isotope JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/isotope.min.js"></script>
	<!-- counterup.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.counterup.min.js"></script>
	<!-- Imageload JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/imageloaded.min.js"></script>
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/wow.min.js"></script>
	<!-- Waypoint JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/waypoint.min.js"></script>
	<!-- main js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('frontView.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>