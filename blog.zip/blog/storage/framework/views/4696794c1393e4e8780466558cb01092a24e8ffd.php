<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	 <!-- Title -->
	<title>chaa.com <?php echo $__env->yieldContent('title_area'); ?></title>

	<!-- CSS -->
	<?php echo $__env->yieldContent('css'); ?>
</head>	
<body>
	<!-- header_area start -->
	<?php echo $__env->make('frontView.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- header_area end -->

	

	<!-- favourite_tea start-->
	<?php echo $__env->yieldContent('favourite'); ?>
	<!-- favourite_tea end-->

	<!-- design_area start-->
	<?php echo $__env->make('frontView.inc.design', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- design_area end-->

	<!-- gallery_area start-->
	<?php echo $__env->yieldContent('gallery_area'); ?>
	<!-- gallery_area end-->

	<!--counter Up start here -->
	<?php echo $__env->yieldContent('counter'); ?>

<!-- footer_area start -->
	<?php echo $__env->make('frontView.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- footer_area end -->

	<!-- js  code -->
	<?php echo $__env->yieldContent('js'); ?>
</body>
</html>