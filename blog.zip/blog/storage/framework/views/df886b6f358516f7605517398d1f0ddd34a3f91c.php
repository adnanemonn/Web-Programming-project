	<section class="copyright_area pt-10 pb-10">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					<p>All Right Resceved &copy; 2019 | design by kazi emran and mahfujur rahman mahfuj</p>
				</div>
			</div>
		</div>
	</section>