<!-- header_area start -->
	<nav class="navbar fixed-top navbar-expand-md flex-nowrap navbar-new-top">
            <a href="<?php echo e(url('http://localhost/blog/public/')); ?>" class="navbar-brand"><h2 class="heading"> chaa<span class="logo_color">.com</span></h2></a>
            <ul class="nav navbar-nav mr-auto"></ul>
            <ul class="navbar-nav flex-row header_link">
                <li class="nav-item">
                    <a class="nav-link px-2"><i class="fas fa-cart-plus" aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
					<a class="box_btn" href="<?php echo e(url('http://localhost/blog/public/login')); ?>">login</a>
                </li>
            </ul>
            <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbar2">
                <span class="navbar-toggler-icon"></span>
            </button>
    </nav>
	<nav class="navbar fixed-top navbar-expand-md navbar-new-bottom">
            <div class="navbar-collapse collapse pt-2 pt-md-0" id="navbar2">

                <ul class="navbar-nav w-100 justify-content-center px-3">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(url('http://localhost/blog/public/')); ?>">home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#service">service</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#latest">latest</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link">Trend</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link">achievement</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">contact</a>
                    </li>
                    <form action="searchProduct" method="get">   
                        <li class="nav-item">
                            <input type="search" name="search" class="form-control" placeholder="Search.."/>
                        </li>
                    </form>    
                </ul>
            </div>
    </nav>
<!-- header_area end -->    