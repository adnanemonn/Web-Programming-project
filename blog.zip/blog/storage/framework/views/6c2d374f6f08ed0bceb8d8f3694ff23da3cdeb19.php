<?php $__env->startSection('title_area'); ?>
	| online delivery website
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<!-- CSS -->


	<!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,600,700,700i" rel="stylesheet"/> 
	<!-- Font Awesome Css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/all.min.css" media="all"/>
	<!-- favicon Css -->
	<link rel="shortcut icon" href="<?php echo e(asset('frontEnd')); ?>/assets/img/favicon.png"/>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd')); ?>/assets/css/bootstrap.min.css"/>
	<!-- owl carousel css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/owl.carousel.css" media="all" />
	<!--magnific-popup-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/magnific-popup.css" media="all" />
	<!-- Main css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/assets/css/style.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('favourite'); ?>
	<section class="customer_info pt-50 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-xl-7">
					<div class="contact_info">
					<form action="<?php echo e(url('')); ?>/placeorder" method="post" id="confirm_order_form">
						<h3>customer information </h3>

						<?php if(\Session::has('success')): ?>
						    <div class="alert alert-success">
						        <ul>
						            <li><?php echo \Session::get('success'); ?></li>
						        </ul>
						    </div>
						<?php endif; ?>
						
						<?php echo csrf_field(); ?>
						<input type="hidden" name="product_name" value="<?php echo e($single_tea->name); ?>">
						<input type="hidden" name="quantity" value="<?php echo e($quantity); ?>">
						<input type="hidden" name="price" value="<?php echo e($quantity*$single_tea->price); ?>">
						<div class="row_field" style="border: 1px solid #D9D9D9;
						padding: 5px 360px 6px 10px;
						text-transform: capitalize;
						font-size: 14px;
						color: #000;">
							<input type="email" name="email" placeholder="enter email"/><br/>
						</div>
						<div class="checkbox_input">
							<input class="input-checkbox" type="checkbox" value="1"/>
							<label class="checkbox__label" for="checkout_remember_me">Keep me up to date on news and exclusive offers </label>
						</div>
						<div class="row_div_field">
							<input type="text" name="first_name" placeholder="first name"/>
							<input type="text" name="last_name" placeholder="last name"/>
						</div>
						<div class="row_field">
							<input type="text" name="address" placeholder="address"/><br/>
						</div>
						<div class="row_field">
							<input type="text" placeholder="city"/><br/>
						</div>
						<div class="row_div_field">
							<select size="1" data-backup="country" aria-required="true class="option_select">
								<option data-code="US" value="United States">United States</option>
								<option data-code="IN" value="India">India</option>
								<option data-code="CA" value="Canada">Canada</option>
								<option data-code="SG" value="Singapore">Singapore</option>
								<option data-code="BD" selected="selected" value="Bangladesh">Bangladesh</option>
							</select>
							<input type="text" placeholder="postal code"/>
						</div>
						<div class="row_field">
							<input type="text" name="phone" placeholder="phone"/><br/>
						</div>
						<div class="checkbox_input">
							<input class="input-checkbox" type="checkbox" value="1"/>
							<label class="checkbox__label" for="checkout_remember_me"> Save this information for next time</label>
						</div>
						<div class="submit_box">
							<a  onclick="event.preventDefault();
                                                     document.getElementById('confirm_order_form').submit();" class="box_btn">submit</a>
						</div>
					</div>
					</form>
				</div>
				<div class="col-xl-5">
					<h3>Total Purchase Info</h3>
					<!-- <div class="row_div_field">
						<input type="text" placeholder="Gift / discount code"/>
						<a href="" class="border_btn">apply</a>
					</div> -->
					<div class="amount_sub">
						<tr class="total-line total-line--subtotal">
							<th class="total-line__name">Subtotal</th>
							<td class="total-line__price">
							<span>$<?php echo e($single_tea->price * $quantity); ?></span>
							</td>
						</tr>
					</div>
					<!-- <div class="total">
						<tr class="total-line total-line--subtotal">
							<th class="total-line__name">total</th>
							<td class="total-line__price">
							<span>$172.60</span>
							</td>
						</tr>
					</div> -->
					<div class="accept_money">
						<h4>we accept</h4>
						<img src="<?php echo e(asset('frontEnd')); ?>/assets//img/corier-1.jpg" alt="" />
						<div class="col-xl-6">
							<img src="<?php echo e(asset('frontEnd')); ?>/assets//img/corier-2.jpg" alt="" />
						</div>
						<div class="col-xl-6">
							<img src="<?php echo e(asset('frontEnd')); ?>/assets//img/corier-3.jpg" alt="" />
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- js  code -->
	<!-- library function -->
	<script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.js"></script>
	<!-- Popper JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/popper.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/bootstrap.min.js"></script>
	<!-- owl.carousel.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/owl.carousel.min.js"></script>
	<!-- Manific Popup JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
	<!-- Isotope JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/isotope.min.js"></script>
	<!-- counterup.min.js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/jquery.counterup.min.js"></script>
	<!-- Imageload JS -->
    <script  src="<?php echo e(asset('frontEnd')); ?>/assets/js/imageloaded.min.js"></script>
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/wow.min.js"></script>
	<!-- Waypoint JS -->
    <script src="<?php echo e(asset('frontEnd')); ?>/assets/js/waypoint.min.js"></script>
	<!-- main js -->
	<script src="<?php echo e(asset('frontEnd')); ?>/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('frontView.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>