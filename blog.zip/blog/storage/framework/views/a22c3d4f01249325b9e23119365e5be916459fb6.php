<?php $__env->startSection('title'); ?>
	Category Entry
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-heading'); ?>
	Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
	<div class="row">
                <div class="col-lg-12">
                    <table class="table table-striped">
                        
                        <tr>
                            <th>product No:</th>
                            <th>Name</th>
                            <th>price:</th>
                            <th>Edit:</th>
                            <th>Delete:</th>
                        </tr>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($single_category->id); ?></td>
                                <td><?php echo e($single_category->name); ?></td>
                                <td>Tk: <?php echo e($single_category->price); ?></td>
                                <td><a style="color: black;" href="<?php echo e(url('')); ?>/edit_product/<?php echo e($single_category->id); ?>">Edit</a></td>
                                <td><a style="color: black;" href="<?php echo e(url('')); ?>/delete_product/<?php echo e($single_category->id); ?>">Delete</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
    	$( document ).ready(function($) {


		  $( "#teatype_submit" ).click(function(e) {
		  		e.preventDefault();
			  	console.log("loll");

			  	$('#teatype_form').submit();
			});

	});

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>