<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tea_type extends Model
{
    //
}
