<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tea_type as tea_type;
class CatagoryController extends Controller
{
    public function index()
    {
    	return view('admin.category.catergoryEntry');
    }

    public function allproducts()
    {
    	$category = tea_type::all();
    	$category = $category->all();
    	// dd($category);
    	return view('admin.category.allcategory' , compact('category'));
    }

     public function editproducts($id)
    {
    	$category = tea_type::find($id);
    	$category = $category->all();
    	// dd($category);
    	return view('admin.category.allcategory' , compact('category'));
    }

     public function deleteproducts($id)
    {
    	$category = tea_type::find($id);
    	$category = $category->all();
    	// dd($category);
    	return view('admin.category.allcategory' , compact('category'));
    }
}
