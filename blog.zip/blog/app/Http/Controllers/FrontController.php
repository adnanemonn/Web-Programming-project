<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\tea_type as tea_type;

class FrontController extends Controller
{
    //
    public function index()
    {
    	$tea_type = tea_type::orderBy('id', 'desc')->take(3)->get()->all();
    	$tea_type_all = tea_type::all()->all();
// dd($tea_type_all);
    	return view('frontView.home.homeContent',compact('tea_type','tea_type_all'));
    }
    public function search(Request $request)
    {
    	$query = $request->get('search');
    	$tea_type = tea_type::where('name','like','%'.$query.'%')->orwhere('price','like','%'.$query.'%')
    	->get();
    	$tea_type_all = tea_type::where('name','like','%'.$query.'%')->orwhere('price','like','%'.$query.'%')
    	->get();
    	//dd($tea_type);
    	return view('frontView.home.homeContent',compact('tea_type','tea_type_all'));
    }
}
