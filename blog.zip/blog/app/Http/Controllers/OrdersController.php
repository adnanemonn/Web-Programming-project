<?php

namespace App\Http\Controllers;

use App\orders as orders;
use App\tea_type as tea_type;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $single_tea = tea_type::find($request->single_tea_id);
        $quantity = $request->quantity; 
        return view('frontView.home.orders',compact('single_tea','quantity'));

        dd($request->all());

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //
        // dd($request->all());

        $order = new orders;

        $order->firstname = $request->first_name;
        $order->lastname = $request->last_name;
        $order->email = $request->email;
        $order->address = $request->address;
        $order->phone = $request->phone;
        $order->quantity = $request->quantity;
        $order->price = $request->price;
        $order->product_name = $request->product_name;

        $order->save();

        return redirect()->back()->with('success', 'Congo Order Placed'); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function all_orders(Request $request)
    {
        //

        $all_orders = orders::all();
        // dd($all_orders->all());

        return view('admin.category.allorders',compact('all_orders'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function show(orders $orders)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function edit(orders $orders)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, orders $orders)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\orders  $orders
     * @return \Illuminate\Http\Response
     */
    public function destroy(orders $orders)
    {
        //
    }
}
