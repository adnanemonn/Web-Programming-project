<?php

namespace App\Http\Controllers;

use App\tea_type as tea_type;
use Illuminate\Http\Request;

class TeaTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
        $tea_type = new tea_type;

        $tea_type->name = $request->name;        
        $tea_type->price = $request->price;        
        $imageName = $tea_type->image = time().'.'.request()->image->getClientOriginalExtension();;        

        request()->image->move(public_path('images'), $imageName);
 
        $tea_type->description = $request->description;  

        $tea_type->save();


        dd($tea_type);
    }


    public function details(Request $request,$id){

        $single_tea = tea_type::find($id);

        return view('frontView.home.tea_details',compact('single_tea'));
        // dd($single_tea);

    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\tea_type  $tea_type
     * @return \Illuminate\Http\Response
     */
    public function show(tea_type $tea_type)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\tea_type  $tea_type
     * @return \Illuminate\Http\Response
     */
    public function edit(tea_type $tea_type)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\tea_type  $tea_type
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tea_type $tea_type)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\tea_type  $tea_type
     * @return \Illuminate\Http\Response
     */
    public function destroy(tea_type $tea_type)
    {
        //
    }
}
